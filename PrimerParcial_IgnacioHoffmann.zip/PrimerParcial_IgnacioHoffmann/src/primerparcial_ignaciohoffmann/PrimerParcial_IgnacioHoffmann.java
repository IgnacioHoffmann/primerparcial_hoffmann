package primerparcial_ignaciohoffmann;

public class PrimerParcial_IgnacioHoffmann {

    public static void main(String[] args) {
        Biblioteca biblioteca = new Biblioteca("Biblioteca Nacional");
        cargarBiblioteca(biblioteca);
        
        System.out.println("Publicaciones disponibles:");
        biblioteca.mostrarPublicaciones();
        System.out.println("");
        
        System.out.println("Lectura de publicaciones: ");
        biblioteca.leerPublicaciones();
    }
    
    public static void cargarBiblioteca(Biblioteca biblioteca) {
        Libro p1 = new Libro("100 anios de soledad", 1967, "Gabriel Garcia Marquez", Genero.NO_FICCION);
        Revista p2 = new Revista("Caras", 2024, 708);
        Ilustracion p3 = new Ilustracion("Figuras Abstractas", 2015, "Juan Diaz", 125, 105);
        Ilustracion p4 = new Ilustracion("Puentes", 2018, "Maria Dominguez", 200, 150);
        Revista p5 = new Revista("Gente", 2024, 1006);
        Libro p6 = new Libro("Historia Argentina", 1995, "Felipe Pigna", Genero.HISTORIA);
        Libro p7 = new Libro("Historia Argentina", 1995, "Sandra Sanz", Genero.FICCION);
        
        biblioteca.agregarPublicacion(p1);
        biblioteca.agregarPublicacion(p2);
        biblioteca.agregarPublicacion(p3);
        biblioteca.agregarPublicacion(p4);
        biblioteca.agregarPublicacion(p5);
        biblioteca.agregarPublicacion(p6);
        
        //repetidos
        try {
            biblioteca.agregarPublicacion(p7);
        } catch (Exception e) {
            System.out.println("p7 " + e.getMessage());
        }
        
        try {
            biblioteca.agregarPublicacion(p6);
        } catch (Exception e) {
            System.out.println("p6 " + e.getMessage());
        }
        
        //null
        try {
            biblioteca.agregarPublicacion(null);
        } catch (Exception e) {
            System.out.println( e.getMessage());
        }
        
        System.out.println("");
    }
}
