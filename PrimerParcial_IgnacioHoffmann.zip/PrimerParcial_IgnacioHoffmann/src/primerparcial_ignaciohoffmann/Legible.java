package primerparcial_ignaciohoffmann;

public interface Legible {
    public void leer();
}
