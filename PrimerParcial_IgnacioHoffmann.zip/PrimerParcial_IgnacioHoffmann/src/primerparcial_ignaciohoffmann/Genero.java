package primerparcial_ignaciohoffmann;

public enum Genero {
    FICCION,
    NO_FICCION,
    CIENCIA,
    HISTORIA;
}
