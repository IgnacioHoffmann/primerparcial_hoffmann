package primerparcial_ignaciohoffmann;
import java.util.List;
import java.util.ArrayList;

public class Biblioteca {
    private String nombre;
    private List<Publicacion> publicaciones;

    public Biblioteca(String nombre) {
        this.nombre = nombre;
        this.publicaciones = new ArrayList<>();
    }
    
    private boolean buscarPublicacion (Publicacion publicacion) {
        return publicaciones.contains(publicacion);
    }
    
    public void agregarPublicacion(Publicacion publicacion) {
        if (publicacion == null) {
            throw new NullPointerException();
        }
        if (buscarPublicacion(publicacion)) {
            throw new PublicacionRepetidaException();
        }
        
        publicaciones.add(publicacion);
    }
    
    public void mostrarPublicaciones(){
        if (!publicaciones.isEmpty()) {
            for (Publicacion publicacion : publicaciones) {
                System.out.println(publicacion);
                System.out.println("--------------------");
            }
        }
    }
    
    public void leerPublicaciones (){
        if (!publicaciones.isEmpty()) {
            for (Publicacion publicacion : publicaciones) {
                if (publicacion instanceof Legible legible) {
                    legible.leer();
                }else{
                    System.out.println("'" + publicacion.getTitulo() + "' es una ilustracion y no se puede leer");
                }
            }
        }
    }
}
