package primerparcial_hoffmann;

public interface Legible {
    public void leer();
}
