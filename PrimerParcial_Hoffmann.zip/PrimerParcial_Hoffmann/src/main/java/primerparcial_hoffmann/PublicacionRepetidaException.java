package primerparcial_hoffmann;

public class PublicacionRepetidaException extends RuntimeException{
    private final static String MESSAGE = "Publicacion repetida, ya fue agregada anteriormente";

    public PublicacionRepetidaException() {
        super(MESSAGE);
    }
    
    
}
