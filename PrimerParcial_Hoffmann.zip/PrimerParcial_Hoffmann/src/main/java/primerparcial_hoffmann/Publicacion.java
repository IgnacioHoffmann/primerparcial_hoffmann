package primerparcial_hoffmann;

import java.util.Objects;

public abstract class Publicacion {
    private String titulo;
    private int anioPublicacion;

    public Publicacion(String titulo, int anioPublicacion) {
        this.titulo = titulo;
        this.anioPublicacion = anioPublicacion;
    }

    public String getTitulo() {
        return titulo;
    }
    
    @Override
    public String toString() {
        return "titulo: " + titulo + ", anioPublicacion: " + anioPublicacion;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        
        Publicacion otro = (Publicacion) obj;
        return titulo.equals(otro.titulo) && anioPublicacion == otro.anioPublicacion;
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(titulo, anioPublicacion);
    }
}
