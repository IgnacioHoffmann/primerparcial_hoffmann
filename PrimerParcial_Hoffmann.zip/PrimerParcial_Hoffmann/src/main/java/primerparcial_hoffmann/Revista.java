package primerparcial_hoffmann;

public class Revista extends Publicacion implements Legible{
    private int numeroEdicion;

    public Revista(String titulo, int anioPublicacion, int numeroEdicion) {
        super(titulo, anioPublicacion);
        this.numeroEdicion = numeroEdicion;
    }

    @Override
    public String toString() {
        return "Revista [" + "Numero de edicion: " + numeroEdicion + "]";
    }

    @Override
    public void leer() {
        System.out.println("Leyendo Revista '" + getTitulo() + "'...");
    }
    
}
