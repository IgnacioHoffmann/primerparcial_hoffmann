package primerparcial_hoffmann;

public enum Genero {
    FICCION,
    NO_FICCION,
    CIENCIA,
    HISTORIA;
}
